/**
 * FacadePatternDemo is the main class to demonstrate the use of the Facade design pattern.
 * It creates a ShapeMaker object and uses it to draw different shapes.
 * @author Tianrui Dong
 * @version 1.0
 */

import org.junit.Test;
import static org.junit.Assert.*;

public class FacadePatternDemo {
    public static void main(String[] args){

        ShapeMaker shapeMaker = new ShapeMaker();

        /**
         * Draws a circle
         */
        shapeMaker.drawCircle();

        /**
         * Draws a rectangle
         */
        shapeMaker.drawRectangle();

        /**
         * Draws a square
         */
        shapeMaker.drawSquare();
    }

}
