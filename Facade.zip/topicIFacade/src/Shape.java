/** This is the shape interface.
 * @author Tianrui Dong
 * @version 1.0
 */
public interface Shape {
    void draw();
}
