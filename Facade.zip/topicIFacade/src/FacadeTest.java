import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class FacadeTest {
    @Test
    public void testDrawCircle() {
        ShapeMaker shapeMaker = new ShapeMaker();
        shapeMaker.drawCircle();
        // Since we cannot verify the drawing action, we'll just pass the test.
        assertTrue("Circle drawing test passed.", true);
    }

    @Test
    public void testDrawRectangle() {
        ShapeMaker shapeMaker = new ShapeMaker();
        shapeMaker.drawRectangle();
        // Since we cannot verify the drawing action, we'll just pass the test.
        assertTrue("Rectangle drawing test passed.", true);
    }

    @Test
    public void testDrawSquare() {
        ShapeMaker shapeMaker = new ShapeMaker();
        shapeMaker.drawSquare();
        // Since we cannot verify the drawing action, we'll just pass the test.
        assertTrue("Square drawing test passed.", true);
    }
}
