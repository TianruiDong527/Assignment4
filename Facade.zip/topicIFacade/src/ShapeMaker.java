/**
 * The ShapeMaker class serves as a facade for drawing various shapes.
 *
 * Attributes:
 * - circle: Shape object representing a circle.
 * - rectangle: Shape object representing a rectangle.
 * - square: Shape object representing a square.
 *
 * Rationale for Attributes:
 * The attributes represent the different shapes that can be drawn.
 * Storing them as class variables allows easy access and instantiation
 * in the constructor for later use in the specific draw methods.
 *
 * @author Tianrui Dong
 * @version 1.0
 */
public class ShapeMaker {
    public Shape circle;
    public Shape rectangle;
    public Shape square;

    /**
     * Constructor for ShapeMaker.
     * Initializes the shapes (circle, rectangle, square) upon instantiation of the class.
     */
    public ShapeMaker(){
        circle = new Circle();
        rectangle  = new Rectangle();
        square = new Square();
    }

    /**
     * Draws a circle by invoking the draw method on the circle object.
     */
    public void drawCircle(){
        circle.draw();
    }

    /**
     * Draws a rectangle by invoking the draw method on the rectangle object.
     */
    public void drawRectangle(){
        rectangle.draw();
    }

    /**
     * Draws a square by invoking the draw method on the square object.
     */
    public void drawSquare(){
        square.draw();
    }
}
