/** When this class is called, a message will be printed to simulate the drawing of a rectangle.
 * @author Tianrui Dong
 * @version 1.0
 */
public class Rectangle implements Shape{
    @Override
    public void draw(){
        /**
         * Draw a rectangle. No parameter is needed.
         */
        System.out.println("Inside Rectangle:: draw() method.");
    }
}
