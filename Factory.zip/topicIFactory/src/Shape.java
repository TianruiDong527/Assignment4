/**
 * This is the shape interface.
 * @author dongtianrui
 * @version 1.0
 */
public interface Shape {
    void draw();
}
