/** When this class is called, a message will be printed to simulate the drawing of a square.
 * @author Tianrui Dong
 * @version 1.0
 */
public class Square implements Shape{
    @Override
    /**
     * Draw a rectangle. No parameter is needed.
     */
    public void draw(){
        System.out.println("Inside Square:: draw() method.");
    }
}
