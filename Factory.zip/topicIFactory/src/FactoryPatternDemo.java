/**
 * This is the main class of factory pattern.
 * This class demonstrates the creation of a Shape object using the ShapeFactory.
 * @author Tianrui Dong
 * @version 1.0
 */

import org.junit.Test;
import static org.junit.Assert.*;

public class FactoryPatternDemo {

    public static void main(String[] args){
        ShapeFactory shapeFactory = new ShapeFactory();
        Shape shape1 = shapeFactory.getShape("CIRCLE");
        shape1.draw();
    }

}
