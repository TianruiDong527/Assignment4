/**
 * This is the factory of shape.
 * @author Tianrui Dong
 * @version 1.0
 */

public class ShapeFactory {

    /**
     * @param shapeType
     * @return objects that implement the Shape interface
     */
    public Shape getShape(String shapeType){
        if (shapeType == null){
            return null;
        }
        if (shapeType.equalsIgnoreCase("CIRCLE")){
            return new Circle();

        } else if (shapeType.equalsIgnoreCase("Rectangle")) {
            return new Rectangle();

        }else if (shapeType.equalsIgnoreCase("Square")) {
            return new Square();
        }
        return null;

        }
    }
