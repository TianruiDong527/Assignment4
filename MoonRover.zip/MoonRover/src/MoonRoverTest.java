import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class VehicleTest {

    @Test
    void testInitialState() {
        Vehicle vehicle = new Vehicle();
        assertTrue(vehicle.getState() instanceof RestState, "Initial state should be RestState.");
    }

    @Test
    void testAcceleratingForward() {
        Vehicle vehicle = new Vehicle();
        vehicle.pedalLeftOnce();
        assertTrue(vehicle.getState() instanceof AcceleratingForward, "Should be in AcceleratingForwardState after pedal left once.");
    }

    @Test
    void testConstantSpeedForward() {
        Vehicle vehicle = new Vehicle();
        vehicle.pedalLeftOnce();
        vehicle.pedalRight3S();
        assertTrue(vehicle.getState() instanceof ConstantSpeedForward, "Should be in ConstantSpeedForwardState after holding right pedal for 3 seconds.");
    }

}

