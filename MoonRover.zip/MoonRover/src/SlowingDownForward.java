public class SlowingDownForward implements State {
    public void pedalLeftOnce(Vehicle context) {

    }

    public void pedalRightOnce(Vehicle context) {
        context.setState(new RestState());
        System.out.println("The moon rover is in rest.");
    }

    public void pedalRight3S(Vehicle context) {

    }

    public void pedalLeft3S(Vehicle context) {
    }
}

