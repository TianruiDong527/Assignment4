public class StatePatternDemo {
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        vehicle.pedalLeftOnce();
        vehicle.pedalRight3S();
    }
}

