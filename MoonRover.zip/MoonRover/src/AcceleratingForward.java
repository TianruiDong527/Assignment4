public class AcceleratingForward implements State {
    public void pedalLeftOnce(Vehicle context) {
        context.setState(new AcceleratingForward());
    }

    public void pedalRightOnce(Vehicle context) {
        context.setState(new SlowingDownForward());
        System.out.println("The moon rover is moving forward and slowing down.");
    }

    public void pedalRight3S(Vehicle context) {
        context.setState(new ConstantSpeedForward());
        System.out.println("The moon rover is moving forward in constant speed.");
    }

    public void pedalLeft3S(Vehicle context) {

    }
}



