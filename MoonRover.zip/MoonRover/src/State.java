public interface State {
    void pedalLeftOnce(Vehicle context);
    void pedalRightOnce(Vehicle context);
    void pedalRight3S(Vehicle context);
    void pedalLeft3S(Vehicle context);
}
