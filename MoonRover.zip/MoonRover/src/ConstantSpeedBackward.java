public class ConstantSpeedBackward implements State {
    public void pedalLeftOnce(Vehicle context) {
    }

    public void pedalRightOnce(Vehicle context) {
        context.setState(new SlowingDownBackward());
        System.out.println("The moon rover is moving backward and slowing down.");
    }

    public void pedalRight3S(Vehicle context) {
    }

    public void pedalLeft3S(Vehicle context) {
    }
}

