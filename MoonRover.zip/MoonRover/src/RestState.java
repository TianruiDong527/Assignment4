public class RestState implements State {
    public void pedalLeftOnce(Vehicle context) {
        context.setState(new AcceleratingForward());
        System.out.println("The moon rover is moving forward and accelerating.");
    }

    public void pedalRightOnce(Vehicle context) {
    }

    public void pedalRight3S(Vehicle context) {
    }

    public void pedalLeft3S(Vehicle context) {
        context.setState(new AcceleratingBackward());
        System.out.println("The moon rover is moving backward and accelerating.");

    }
}

// 定义其他状态类...
