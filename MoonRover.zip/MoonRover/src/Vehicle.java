public class Vehicle {
    private State state;

    public Vehicle() {
        state = new RestState();
    }

    public void setState(State state) {
        this.state = state;
    }

    public State getState() {
        return state;
    }

    public void pedalLeftOnce() {
        state.pedalLeftOnce(this);
    }

    public void pedalRightOnce() {
        state.pedalRightOnce(this);
    }

    public void pedalRight3S() {
        state.pedalRight3S(this);
    }

    public void pedalLeft3S() {
        state.pedalRight3S(this);
    }

}

