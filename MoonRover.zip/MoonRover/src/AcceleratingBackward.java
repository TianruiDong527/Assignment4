public class AcceleratingBackward implements State {
    public void pedalLeftOnce(Vehicle context) {
    }

    public void pedalRightOnce(Vehicle context) {
        context.setState(new SlowingDownBackward());
        System.out.println("The moon rover is moving backward and slowing down");
    }

    public void pedalRight3S(Vehicle context) {
        context.setState(new ConstantSpeedBackward());
        System.out.println("The moon rover is moving backward in constant speed.");
    }
    public void pedalLeft3S(Vehicle context) {
    }
}


