public class ConstantSpeedForward implements State {
    public void pedalLeftOnce(Vehicle context) {

    }

    public void pedalRightOnce(Vehicle context) {
        context.setState(new SlowingDownForward());
        System.out.println("The moon rover is moving forward and slowing down.");
    }

    public void pedalRight3S(Vehicle context) {
    }

    public void pedalLeft3S(Vehicle context) {
    }
}


