/**
 * This is the main class of singleton pattern.
 * It accesses the single instance of the {@code SingleObject} class
 * and calls its {@code showMessage} method.
 * @author dongtianrui
 * @version 1.0
 */
public class SingletonPatternDemo {
    public  static void main(String[] args){
        // Gets the only object available from SingleObject class
        SingleObject object = SingleObject.getInstance();

        // Shows the message from the single instance
        object.showMessage();
    }
}
