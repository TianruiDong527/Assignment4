/**
 * The {@code SingleObject} class implements the Singleton design pattern. This pattern ensures that
 * only one instance of {@code SingleObject} can be created. The class provides a static method
 * to access its single instance and a method to display a message.
 *
 * @author dongtianrui
 * @version 1.0
 */
public class SingleObject {

    // The single instance of the class
    private static SingleObject instance = new SingleObject();

    /**
     * Private constructor to prevent instantiation from outside the class.
     */
    private SingleObject(){}

    /**
     * Provides access to the single instance of the class.
     *
     * @return The single instance of {@code SingleObject}.
     */
    public static SingleObject getInstance(){
        return instance;
    }

    /**
     * Prints a message to the console.
     * This method demonstrates an action that can be performed by the singleton instance.
     */
    public void showMessage(){
        System.out.println("Hello, World!");
    }
}
